%% 
%Jason Galvan and Emily Hatton
%Please note this was a collective effort - we worked on all problems together.

%% Setting up 
%Clearing workspace and closing all plots
clear all; close all;

%Variables as defined in Coding Application 2
lat_range = [22 90];
lon_range = [85 12];
epoch_range = [1950 2019];
min_frac = 0.85;
ref_point = [70,-40];
t_r = 1985;
t_a = 1990.5;

%% Question 1

%Reading PSMSL catalog into a catalog structure
[wna_data,psmsl_catalog] = read_psmsl_data(lat_range,lon_range,epoch_range,min_frac);


%% Question 2

% Plot map of region, showing the locations & names of the WNA tide-guage
% sites
plot_coast(wna_data);


%% Question 3

% Calcuate the least-squares parameter estimates & uncertainties for all
% WNA sites
solution = solve_all_sites(wna_data, t_r, t_a);


%% Question 4

%Write a text table inot the Command window
write_table(solution, psmsl_catalog)


%% Question 5

%Create scatter plot of the sea-level accelerations estimate vs. angular
%distance from specified reference location
rsl_vs_dist(solution, psmsl_catalog, ref_point);


%% Question 6

%Make plot shoing the RSL observations and model for the tide-gage site
%having ID=235

plot_data_model(wna_data, solution, psmsl_catalog, 235, [t_r, t_a])

